<?php include 'admin/db_connect.php' ?>

<?php
	$qry = $conn->query("SELECT * FROM vacancy where id=".$_GET['id'])->fetch_array();
	foreach($qry as $k =>$v){
		$$k = $v;
	}
?>
<div class="container-fluid">
	<form id="manage-application">
		<input type="hidden" name="id" value="">
		<input type="hidden" name="position_id" value="<?php echo $_GET['id'] ?>">
	<div class="col-md-12">
		<div class="row">
			<h3>Lowongan Kerja <?php echo $position ?></h3>
		</div>
		<hr>
		<div class="row form-group">
			<div class="col-md-4">
				<label for="" class="control-label">Nama Lengkap</label>
				<input type="text" class="form-control" name="lastname" required="">
			</div>
			<div class="col-md-4">
				<label for="" class="control-label">Pendidikan</label>
				<select name="firstname" id="" class="custom-select browser-default">
				    <option value="" selected disabled>- pilih -</option>    
					<option>SD</option>
					<option>SMP</option>
					<option>SMA</option>
					<option>D3</option>
					<option>S1</option>
					<option>S2</option>
					<option>S3</option>
				</select>
				
			</div>
			<div class="col-md-4">
				<label for="" class="control-label">Usia</label>
				<input type="number" class="form-control" name="middlename" required="">
			</div>
		</div>
		<div class="row form-group">
			<div class="col-md-4">
				<label for="" class="control-label">Jenis Kelamin</label>
				<select name="gender" id="" class="custom-select browser-default">
				    <option value="" selected disabled>- pilih -</option>    
					<option>Laki-laki</option>
					<option>Perempuan</option>
				</select>
			</div>
		
				<div class="col-md-4">
				<label for="" class="control-label">Domisili</label>
				<select name="email" id="" class="custom-select browser-default">
				    <option value="" selected disabled>- pilih -</option>    
					<option>Jakarta Selatan</option>
					<option>Jakarta Timur</option>
					<option>Jakarta Pusat</option>
					<option>Jakarta Barat</option>
					<option>Jakarta Utara</option>
					<option>Luar Wilayah DKI jakarta</option>
				</select>
			</div>

			<div class="col-md-4">
				<label for="" class="control-label">No HP</label>
				<input type="number" class="form-control" name="contact" required="">
			</div>
		</div>
		<div class="row form-group">
			<div class="col-md-7">
				<label for="" class="control-label">Alamat</label>
				<textarea name="address" id="" cols="30" rows="3" required class="form-control"></textarea>
			</div>
		</div>
		
		<div class="row form-group">
			<div class="col-md-7">
				<label for="" class="control-label">Deskripsikan Keahlian anda</label>
				<textarea name="cover_letter" id="" cols="30" rows="3" placeholder="(Optional)" class="form-control"></textarea>
			</div>
		</div>
		
		
		
		
	
		<div class="row form-group">
			<div class="col-md-7">
				<label for="" class="control-label">NOTE : Semua poin persyaratan umum di scan dalam bentuk PDF dan dijadikan dalam 1 file PDF</label>
				
			</div>
			
			<div class="col-md-7">
				<label for="" class="control-label"><font color="red">Maksimum File PDF = 8MB</font></label>
				
			</div>
		</div>
		<div class="row form-group">
			<div class="input-group col-md-4 mb-3">
				<div class="input-group-prepend">
			    <span class="input-group-text" id="">PDF</span>
			  </div>
			  <div class="custom-file">
			    <input type="file" class="custom-file-input" id="resume" onchange="displayfname(this,$(this))" name="resume" accept="application/pdf">
			    <label class="custom-file-label" for="resume">Choose file</label>
			  </div>
			  
			</div>
		</div>
	</div>
	</form>
</div>

<script>
	function displayfname(input,_this) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function (e) {
        	console.log(input.files[0].name)
        	_this.siblings('label').html(input.files[0].name);
        }

        reader.readAsDataURL(input.files[0]);
    }
}
$(document).ready(function(){
	$('#manage-application').submit(function(e){
		e.preventDefault()
		start_load()
		$.ajax({
			url:'admin/ajax.php?action=save_application',
			data: new FormData($(this)[0]),
		    cache: false,
		    contentType: false,
		    processData: false,
		    method: 'POST',
		    type: 'POST',
			error:err=>{
				console.log(err)
			},
			success:function(resp){
				if(resp == 1){
					alert_toast('Application successfully submitted.','success')
					setTimeout(function(){
						location.reload()
					},1000)
				}
			}
		})

	})
})
</script>